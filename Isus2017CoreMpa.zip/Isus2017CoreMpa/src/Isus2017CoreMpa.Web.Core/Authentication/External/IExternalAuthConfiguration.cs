﻿using System.Collections.Generic;

namespace Isus2017CoreMpa.Authentication.External
{
    public interface IExternalAuthConfiguration
    {
        List<ExternalLoginProviderInfo> Providers { get; }
    }
}
