﻿using Abp.AutoMapper;
using Isus2017CoreMpa.Authentication.External;

namespace Isus2017CoreMpa.Models.TokenAuth
{
    [AutoMapFrom(typeof(ExternalLoginProviderInfo))]
    public class ExternalLoginProviderInfoModel
    {
        public string Name { get; set; }

        public string ClientId { get; set; }
    }
}
