using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace Isus2017CoreMpa.Controllers
{
    public abstract class Isus2017CoreMpaControllerBase: AbpController
    {
        protected Isus2017CoreMpaControllerBase()
        {
            LocalizationSourceName = Isus2017CoreMpaConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}