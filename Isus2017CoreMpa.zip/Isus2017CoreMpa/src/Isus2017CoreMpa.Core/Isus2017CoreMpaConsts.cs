﻿namespace Isus2017CoreMpa
{
    public class Isus2017CoreMpaConsts
    {
        public const string LocalizationSourceName = "Isus2017CoreMpa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}