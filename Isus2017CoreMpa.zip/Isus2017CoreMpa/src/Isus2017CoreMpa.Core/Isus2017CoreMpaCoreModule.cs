﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using Abp.Timing;
using Abp.Zero;
using Isus2017CoreMpa.Localization;
using Abp.Zero.Configuration;
using Isus2017CoreMpa.MultiTenancy;
using Isus2017CoreMpa.Authorization.Roles;
using Isus2017CoreMpa.Authorization.Users;
using Isus2017CoreMpa.Configuration;
using Isus2017CoreMpa.Timing;

namespace Isus2017CoreMpa
{
    [DependsOn(typeof(AbpZeroCoreModule))]
    public class Isus2017CoreMpaCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            //Declare entity types
            Configuration.Modules.Zero().EntityTypes.Tenant = typeof(Tenant);
            Configuration.Modules.Zero().EntityTypes.Role = typeof(Role);
            Configuration.Modules.Zero().EntityTypes.User = typeof(User);

            Isus2017CoreMpaLocalizationConfigurer.Configure(Configuration.Localization);

            //Enable this line to create a multi-tenant application.
            Configuration.MultiTenancy.IsEnabled = Isus2017CoreMpaConsts.MultiTenancyEnabled;

            //Configure roles
            AppRoleConfig.Configure(Configuration.Modules.Zero().RoleManagement);

            Configuration.Settings.Providers.Add<AppSettingProvider>();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(Isus2017CoreMpaCoreModule).GetAssembly());
        }

        public override void PostInitialize()
        {
            IocManager.Resolve<AppTimes>().StartupTime = Clock.Now;
        }
    }
}