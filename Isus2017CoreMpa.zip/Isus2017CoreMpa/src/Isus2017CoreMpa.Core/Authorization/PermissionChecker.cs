﻿using Abp.Authorization;
using Isus2017CoreMpa.Authorization.Roles;
using Isus2017CoreMpa.Authorization.Users;

namespace Isus2017CoreMpa.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
