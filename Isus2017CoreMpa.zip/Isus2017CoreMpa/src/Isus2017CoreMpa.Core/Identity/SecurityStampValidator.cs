﻿using Abp.Authorization;
using Isus2017CoreMpa.Authorization.Roles;
using Isus2017CoreMpa.Authorization.Users;
using Isus2017CoreMpa.MultiTenancy;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Options;

namespace Isus2017CoreMpa.Identity
{
    public class SecurityStampValidator : AbpSecurityStampValidator<Tenant, Role, User>
    {
        public SecurityStampValidator(
            IOptions<IdentityOptions> options, 
            SignInManager signInManager) 
            : base(options, signInManager)
        {
        }
    }
}