﻿using Abp.MultiTenancy;
using Isus2017CoreMpa.Authorization.Users;

namespace Isus2017CoreMpa.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}