﻿using System.Reflection;
using Abp.Configuration.Startup;
using Abp.Localization.Dictionaries;
using Abp.Localization.Dictionaries.Xml;
using Abp.Reflection.Extensions;

namespace Isus2017CoreMpa.Localization
{
    public static class Isus2017CoreMpaLocalizationConfigurer
    {
        public static void Configure(ILocalizationConfiguration localizationConfiguration)
        {
            localizationConfiguration.Sources.Add(
                new DictionaryBasedLocalizationSource(Isus2017CoreMpaConsts.LocalizationSourceName,
                    new XmlEmbeddedFileLocalizationDictionaryProvider(
                        typeof(Isus2017CoreMpaLocalizationConfigurer).GetAssembly(),
                        "Isus2017CoreMpa.Localization.SourceFiles"
                    )
                )
            );
        }
    }
}