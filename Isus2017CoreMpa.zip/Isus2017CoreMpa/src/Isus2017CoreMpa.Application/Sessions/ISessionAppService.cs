﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Isus2017CoreMpa.Sessions.Dto;

namespace Isus2017CoreMpa.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
