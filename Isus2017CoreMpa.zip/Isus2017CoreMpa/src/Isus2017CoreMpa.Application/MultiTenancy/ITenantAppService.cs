﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Isus2017CoreMpa.MultiTenancy.Dto;

namespace Isus2017CoreMpa.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
