﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using Isus2017CoreMpa.Configuration.Dto;

namespace Isus2017CoreMpa.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : Isus2017CoreMpaAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
