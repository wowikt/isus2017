﻿using System.Threading.Tasks;
using Isus2017CoreMpa.Configuration.Dto;

namespace Isus2017CoreMpa.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}