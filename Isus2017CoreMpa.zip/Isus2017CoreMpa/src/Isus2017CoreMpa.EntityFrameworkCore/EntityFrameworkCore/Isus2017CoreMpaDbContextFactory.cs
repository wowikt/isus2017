﻿using Isus2017CoreMpa.Configuration;
using Isus2017CoreMpa.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;

namespace Isus2017CoreMpa.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class Isus2017CoreMpaDbContextFactory : IDbContextFactory<Isus2017CoreMpaDbContext>
    {
        public Isus2017CoreMpaDbContext Create(DbContextFactoryOptions options)
        {
            var builder = new DbContextOptionsBuilder<Isus2017CoreMpaDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            Isus2017CoreMpaDbContextConfigurer.Configure(builder, configuration.GetConnectionString(Isus2017CoreMpaConsts.ConnectionStringName));
            
            return new Isus2017CoreMpaDbContext(builder.Options);
        }
    }
}