﻿using Abp.Zero.EntityFrameworkCore;
using Isus2017CoreMpa.Authorization.Roles;
using Isus2017CoreMpa.Authorization.Users;
using Isus2017CoreMpa.MultiTenancy;
using Microsoft.EntityFrameworkCore;

namespace Isus2017CoreMpa.EntityFrameworkCore
{
    public class Isus2017CoreMpaDbContext : AbpZeroDbContext<Tenant, Role, User, Isus2017CoreMpaDbContext>
    {
        /* Define an IDbSet for each entity of the application */
        
        public Isus2017CoreMpaDbContext(DbContextOptions<Isus2017CoreMpaDbContext> options)
            : base(options)
        {

        }
    }
}
