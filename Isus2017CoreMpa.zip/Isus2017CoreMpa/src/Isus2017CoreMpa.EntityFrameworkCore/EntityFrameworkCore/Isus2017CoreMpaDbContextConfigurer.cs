using Microsoft.EntityFrameworkCore;

namespace Isus2017CoreMpa.EntityFrameworkCore
{
    public static class Isus2017CoreMpaDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<Isus2017CoreMpaDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }
    }
}