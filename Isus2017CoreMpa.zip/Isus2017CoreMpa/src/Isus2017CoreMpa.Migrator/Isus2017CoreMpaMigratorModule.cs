using Abp.Events.Bus;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Castle.MicroKernel.Registration;
using Microsoft.Extensions.Configuration;
using Isus2017CoreMpa.Configuration;
using Isus2017CoreMpa.EntityFrameworkCore;
using Isus2017CoreMpa.Migrator.DependencyInjection;

namespace Isus2017CoreMpa.Migrator
{
    [DependsOn(typeof(Isus2017CoreMpaEntityFrameworkModule))]
    public class Isus2017CoreMpaMigratorModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public Isus2017CoreMpaMigratorModule(Isus2017CoreMpaEntityFrameworkModule abpProjectNameEntityFrameworkModule)
        {
            abpProjectNameEntityFrameworkModule.SkipDbSeed = true;

            _appConfiguration = AppConfigurations.Get(
                typeof(Isus2017CoreMpaMigratorModule).GetAssembly().GetDirectoryPathOrNull()
            );
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(
                Isus2017CoreMpaConsts.ConnectionStringName
                );

            Configuration.BackgroundJobs.IsJobExecutionEnabled = false;
            Configuration.ReplaceService(typeof(IEventBus), () =>
            {
                IocManager.IocContainer.Register(
                    Component.For<IEventBus>().Instance(NullEventBus.Instance)
                );
            });
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(Isus2017CoreMpaMigratorModule).GetAssembly());
            ServiceCollectionRegistrar.Register(IocManager);
        }
    }
}