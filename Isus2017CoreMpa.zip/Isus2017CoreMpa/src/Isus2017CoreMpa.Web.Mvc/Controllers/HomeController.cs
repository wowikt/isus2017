﻿using Abp.AspNetCore.Mvc.Authorization;
using Isus2017CoreMpa.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace Isus2017CoreMpa.Web.Controllers
{
    [AbpMvcAuthorize]
    public class HomeController : Isus2017CoreMpaControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}