﻿using Isus2017CoreMpa.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace Isus2017CoreMpa.Web.Controllers
{
    public class AboutController : Isus2017CoreMpaControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}