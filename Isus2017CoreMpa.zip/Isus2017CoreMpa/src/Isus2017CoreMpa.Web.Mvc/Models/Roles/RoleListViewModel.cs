﻿using System.Collections.Generic;
using Isus2017CoreMpa.Roles.Dto;

namespace Isus2017CoreMpa.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}
