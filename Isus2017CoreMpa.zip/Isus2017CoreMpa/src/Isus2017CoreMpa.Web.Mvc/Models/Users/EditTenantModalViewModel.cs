using System.Collections.Generic;
using System.Linq;
using Isus2017CoreMpa.Roles.Dto;
using Isus2017CoreMpa.Users.Dto;

namespace Isus2017CoreMpa.Web.Models.Users
{
    public class EditUserModalViewModel
    {
        public UserDto User { get; set; }

        public IReadOnlyList<RoleDto> Roles { get; set; }

        public bool UserIsInRole(RoleDto role)
        {
            return User.RoleNames != null && User.RoleNames.Any(r => r == role.NormalizedName);
        }
    }
}