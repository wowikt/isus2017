using System.Collections.Generic;
using Isus2017CoreMpa.Roles.Dto;
using Isus2017CoreMpa.Users.Dto;

namespace Isus2017CoreMpa.Web.Models.Users
{
    public class UserListViewModel
    {
        public IReadOnlyList<UserDto> Users { get; set; }

        public IReadOnlyList<RoleDto> Roles { get; set; }
    }
}