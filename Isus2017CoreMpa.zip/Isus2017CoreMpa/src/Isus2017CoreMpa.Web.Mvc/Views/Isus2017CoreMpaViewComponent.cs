﻿using Abp.AspNetCore.Mvc.ViewComponents;

namespace Isus2017CoreMpa.Web.Views
{
    public abstract class Isus2017CoreMpaViewComponent : AbpViewComponent
    {
        protected Isus2017CoreMpaViewComponent()
        {
            LocalizationSourceName = Isus2017CoreMpaConsts.LocalizationSourceName;
        }
    }
}