﻿using Abp.AspNetCore.Mvc.Views;
using Abp.Runtime.Session;
using Microsoft.AspNetCore.Mvc.Razor.Internal;

namespace Isus2017CoreMpa.Web.Views
{
    public abstract class Isus2017CoreMpaRazorPage<TModel> : AbpRazorPage<TModel>
    {
        [RazorInject]
        public IAbpSession AbpSession { get; set; }

        protected Isus2017CoreMpaRazorPage()
        {
            LocalizationSourceName = Isus2017CoreMpaConsts.LocalizationSourceName;
        }
    }
}
