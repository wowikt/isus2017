﻿using Isus2017CoreMpa.Configuration.Ui;

namespace Isus2017CoreMpa.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
