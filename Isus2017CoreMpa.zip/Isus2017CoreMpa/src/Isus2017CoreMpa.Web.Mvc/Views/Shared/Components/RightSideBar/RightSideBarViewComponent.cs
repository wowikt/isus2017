﻿using System.Linq;
using System.Threading.Tasks;
using Abp.Configuration;
using Isus2017CoreMpa.Configuration;
using Isus2017CoreMpa.Configuration.Ui;
using Microsoft.AspNetCore.Mvc;

namespace Isus2017CoreMpa.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewComponent : Isus2017CoreMpaViewComponent
    {
        private readonly ISettingManager _settingManager;

        public RightSideBarViewComponent(ISettingManager settingManager)
        {
            _settingManager = settingManager;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var themeName = await _settingManager.GetSettingValueAsync(AppSettingNames.UiTheme);

            var viewModel = new RightSideBarViewModel
            {
                CurrentTheme = UiThemes.All.FirstOrDefault(t => t.CssClass == themeName)
            };

            return View(viewModel);
        }
    }
}
