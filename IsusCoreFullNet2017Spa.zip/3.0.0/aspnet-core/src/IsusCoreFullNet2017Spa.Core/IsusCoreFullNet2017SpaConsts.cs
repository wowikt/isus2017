﻿namespace IsusCoreFullNet2017Spa
{
    public class IsusCoreFullNet2017SpaConsts
    {
        public const string LocalizationSourceName = "IsusCoreFullNet2017Spa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}