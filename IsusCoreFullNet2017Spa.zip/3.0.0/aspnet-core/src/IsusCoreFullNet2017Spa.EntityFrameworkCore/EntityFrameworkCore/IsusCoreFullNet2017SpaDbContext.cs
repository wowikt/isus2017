﻿using Abp.Zero.EntityFrameworkCore;
using IsusCoreFullNet2017Spa.Authorization.Roles;
using IsusCoreFullNet2017Spa.Authorization.Users;
using IsusCoreFullNet2017Spa.MultiTenancy;
using Microsoft.EntityFrameworkCore;

namespace IsusCoreFullNet2017Spa.EntityFrameworkCore
{
    public class IsusCoreFullNet2017SpaDbContext : AbpZeroDbContext<Tenant, Role, User, IsusCoreFullNet2017SpaDbContext>
    {
        /* Define an IDbSet for each entity of the application */
        
        public IsusCoreFullNet2017SpaDbContext(DbContextOptions<IsusCoreFullNet2017SpaDbContext> options)
            : base(options)
        {

        }
    }
}
