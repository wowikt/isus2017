﻿namespace IsusCore2017Spa
{
    public class IsusCore2017SpaConsts
    {
        public const string LocalizationSourceName = "IsusCore2017Spa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}