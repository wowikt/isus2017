﻿namespace Isus2017CoreSpa
{
    public class Isus2017CoreSpaConsts
    {
        public const string LocalizationSourceName = "Isus2017CoreSpa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}