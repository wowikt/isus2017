﻿declare namespace abp {

    //TODO: Gets JQuery.AjaxOptions and returns JQuery.Promise

    function ajax(userOptions: any): any;
    
}