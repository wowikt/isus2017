﻿namespace Isus2017Spa
{
    public class Isus2017SpaConsts
    {
        public const string LocalizationSourceName = "Isus2017Spa";

        public const bool MultiTenancyEnabled = true;
    }
}