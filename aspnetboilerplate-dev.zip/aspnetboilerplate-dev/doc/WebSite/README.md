ASP.NET Boilerplate Documentation
---------------------------------

This documentation is published on http://www.aspnetboilerplate.com/Pages/Documents

If you want to contribute it, please follow this steps:

* If it's a minor change (typo or grammer fixes or adding a few sentences), you can directly make it and send Pull Request.
* If it's a major change (creating a new document or adding a new section to an existing document),
create an issue describing the changes you want to make.
* We will evaluate the change you request. If it's accepted, you can make the change and send PR.
* Please follow the same standards of current documents.
