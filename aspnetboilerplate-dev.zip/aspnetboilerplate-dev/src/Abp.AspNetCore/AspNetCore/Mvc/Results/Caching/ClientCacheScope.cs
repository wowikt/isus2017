﻿namespace Abp.AspNetCore.Mvc.Results.Caching
{
    public enum ClientCacheScope
    {
        Public,
        Private
    }
}