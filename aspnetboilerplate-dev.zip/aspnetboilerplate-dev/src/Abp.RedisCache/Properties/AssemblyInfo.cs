﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ASP.NET Boilerplate - Redis cache implementation")]
[assembly: AssemblyDescription("ASP.NET Boilerplate - Redis cache implementation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Volosoft")]
[assembly: AssemblyProduct("Abp.RedisCache")]
[assembly: AssemblyCopyright("Copyright © 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("428822a6-8e50-4bd0-9da3-1da3c27728b7")]



