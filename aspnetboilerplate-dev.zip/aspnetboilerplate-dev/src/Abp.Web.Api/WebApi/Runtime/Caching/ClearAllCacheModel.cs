namespace Abp.WebApi.Runtime.Caching
{
    public class ClearAllCacheModel
    {
        public string Password { get; set; }
    }
}