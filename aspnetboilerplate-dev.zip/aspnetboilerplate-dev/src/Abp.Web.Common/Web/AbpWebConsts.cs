﻿namespace Abp.Web
{
    public static class AbpWebConsts
    {
        public const string LocalizaionSourceName = "AbpWeb";
    }
}