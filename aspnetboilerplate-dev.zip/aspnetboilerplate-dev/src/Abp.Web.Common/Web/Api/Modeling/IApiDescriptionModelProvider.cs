namespace Abp.Web.Api.Modeling
{
    public interface IApiDescriptionModelProvider
    {
        ApplicationApiDescriptionModel CreateModel();
    }
}