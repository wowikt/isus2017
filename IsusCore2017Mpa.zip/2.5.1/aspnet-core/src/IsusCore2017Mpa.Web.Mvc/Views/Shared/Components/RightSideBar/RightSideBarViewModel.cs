﻿using IsusCore2017Mpa.Configuration.Ui;

namespace IsusCore2017Mpa.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
