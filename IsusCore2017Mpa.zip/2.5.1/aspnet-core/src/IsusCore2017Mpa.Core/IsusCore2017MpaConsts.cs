﻿namespace IsusCore2017Mpa
{
    public class IsusCore2017MpaConsts
    {
        public const string LocalizationSourceName = "IsusCore2017Mpa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}