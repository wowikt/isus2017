﻿namespace IsusCoreFullNet2017Mpa.Authorization.Accounts.Dto
{
    public class RegisterOutput
    {
        public bool CanLogin { get; set; }
    }
}