﻿namespace IsusCoreFullNet2017Mpa
{
    public class IsusCoreFullNet2017MpaConsts
    {
        public const string LocalizationSourceName = "IsusCoreFullNet2017Mpa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}