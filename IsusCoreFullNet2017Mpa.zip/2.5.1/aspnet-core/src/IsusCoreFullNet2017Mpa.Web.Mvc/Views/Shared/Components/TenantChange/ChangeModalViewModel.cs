﻿namespace IsusCoreFullNet2017Mpa.Web.Views.Shared.Components.TenantChange
{
    public class ChangeModalViewModel
    {
        public string TenancyName { get; set; }
    }
}
