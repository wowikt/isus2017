﻿using IsusCoreFullNet2017Mpa.Configuration.Ui;

namespace IsusCoreFullNet2017Mpa.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
