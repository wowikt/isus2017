﻿using System.Data.Entity;
using System.Reflection;
using Abp.Modules;
using Abp.Zero.EntityFramework;
using Isus2017Mpa.EntityFramework;

namespace Isus2017Mpa
{
    [DependsOn(typeof(AbpZeroEntityFrameworkModule), typeof(Isus2017MpaCoreModule))]
    public class Isus2017MpaDataModule : AbpModule
    {
        public override void PreInitialize()
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<Isus2017MpaDbContext>());

            Configuration.DefaultNameOrConnectionString = "Default";
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}
