﻿using System.Data.Common;
using Abp.Zero.EntityFramework;
using Isus2017Mpa.Authorization.Roles;
using Isus2017Mpa.Authorization.Users;
using Isus2017Mpa.MultiTenancy;

namespace Isus2017Mpa.EntityFramework
{
    public class Isus2017MpaDbContext : AbpZeroDbContext<Tenant, Role, User>
    {
        //TODO: Define an IDbSet for your Entities...

        /* NOTE: 
         *   Setting "Default" to base class helps us when working migration commands on Package Manager Console.
         *   But it may cause problems when working Migrate.exe of EF. If you will apply migrations on command line, do not
         *   pass connection string name to base classes. ABP works either way.
         */
        public Isus2017MpaDbContext()
            : base("Default")
        {

        }

        /* NOTE:
         *   This constructor is used by ABP to pass connection string defined in Isus2017MpaDataModule.PreInitialize.
         *   Notice that, actually you will not directly create an instance of Isus2017MpaDbContext since ABP automatically handles it.
         */
        public Isus2017MpaDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {

        }

        //This constructor is used in tests
        public Isus2017MpaDbContext(DbConnection existingConnection)
         : base(existingConnection, false)
        {

        }

        public Isus2017MpaDbContext(DbConnection existingConnection, bool contextOwnsConnection)
         : base(existingConnection, contextOwnsConnection)
        {

        }
    }
}
