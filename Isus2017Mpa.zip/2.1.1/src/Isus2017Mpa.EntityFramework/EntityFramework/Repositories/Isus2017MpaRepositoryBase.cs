﻿using Abp.Domain.Entities;
using Abp.EntityFramework;
using Abp.EntityFramework.Repositories;

namespace Isus2017Mpa.EntityFramework.Repositories
{
    public abstract class Isus2017MpaRepositoryBase<TEntity, TPrimaryKey> : EfRepositoryBase<Isus2017MpaDbContext, TEntity, TPrimaryKey>
        where TEntity : class, IEntity<TPrimaryKey>
    {
        protected Isus2017MpaRepositoryBase(IDbContextProvider<Isus2017MpaDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //add common methods for all repositories
    }

    public abstract class Isus2017MpaRepositoryBase<TEntity> : Isus2017MpaRepositoryBase<TEntity, int>
        where TEntity : class, IEntity<int>
    {
        protected Isus2017MpaRepositoryBase(IDbContextProvider<Isus2017MpaDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //do not add any method here, add to the class above (since this inherits it)
    }
}
