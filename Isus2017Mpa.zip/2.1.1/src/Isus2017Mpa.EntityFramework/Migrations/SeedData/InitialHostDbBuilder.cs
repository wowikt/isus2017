﻿using Isus2017Mpa.EntityFramework;
using EntityFramework.DynamicFilters;

namespace Isus2017Mpa.Migrations.SeedData
{
    public class InitialHostDbBuilder
    {
        private readonly Isus2017MpaDbContext _context;

        public InitialHostDbBuilder(Isus2017MpaDbContext context)
        {
            _context = context;
        }

        public void Create()
        {
            _context.DisableAllFilters();

            new DefaultEditionsCreator(_context).Create();
            new DefaultLanguagesCreator(_context).Create();
            new HostRoleAndUserCreator(_context).Create();
            new DefaultSettingsCreator(_context).Create();
        }
    }
}
