﻿namespace Isus2017Mpa
{
    public class Isus2017MpaConsts
    {
        public const string LocalizationSourceName = "Isus2017Mpa";

        public const bool MultiTenancyEnabled = true;
    }
}