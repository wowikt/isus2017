﻿using Abp.Authorization;
using Isus2017Mpa.Authorization.Roles;
using Isus2017Mpa.Authorization.Users;

namespace Isus2017Mpa.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
