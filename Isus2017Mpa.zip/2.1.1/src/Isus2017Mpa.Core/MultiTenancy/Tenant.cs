﻿using Abp.MultiTenancy;
using Isus2017Mpa.Authorization.Users;

namespace Isus2017Mpa.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}