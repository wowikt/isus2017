﻿using System.Web.Mvc;

namespace Isus2017Mpa.Web.Controllers
{
    public class AboutController : Isus2017MpaControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}