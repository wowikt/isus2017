﻿using Abp.Web.Mvc.Views;

namespace Isus2017Mpa.Web.Views
{
    public abstract class Isus2017MpaWebViewPageBase : Isus2017MpaWebViewPageBase<dynamic>
    {

    }

    public abstract class Isus2017MpaWebViewPageBase<TModel> : AbpWebViewPage<TModel>
    {
        protected Isus2017MpaWebViewPageBase()
        {
            LocalizationSourceName = Isus2017MpaConsts.LocalizationSourceName;
        }
    }
}