﻿using Abp.AutoMapper;
using Isus2017Mpa.Sessions.Dto;

namespace Isus2017Mpa.Web.Models.Account
{
    [AutoMapFrom(typeof(GetCurrentLoginInformationsOutput))]
    public class TenantChangeViewModel
    {
        public TenantLoginInfoDto Tenant { get; set; }
    }
}