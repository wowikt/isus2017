using Isus2017Mpa.Configuration.Ui;

namespace Isus2017Mpa.Web.Models.Layout
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}