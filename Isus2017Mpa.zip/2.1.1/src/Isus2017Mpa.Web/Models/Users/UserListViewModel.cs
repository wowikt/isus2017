﻿using System.Collections.Generic;
using Isus2017Mpa.Roles.Dto;
using Isus2017Mpa.Users.Dto;

namespace Isus2017Mpa.Web.Models.Users
{
    public class UserListViewModel
    {
        public IReadOnlyList<UserDto> Users { get; set; }

        public IReadOnlyList<RoleDto> Roles { get; set; }
    }
}