﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Isus2017Mpa.Sessions.Dto;

namespace Isus2017Mpa.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
