﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using Isus2017Mpa.MultiTenancy;

namespace Isus2017Mpa.Sessions.Dto
{
    [AutoMapFrom(typeof(Tenant))]
    public class TenantLoginInfoDto : EntityDto
    {
        public string TenancyName { get; set; }

        public string Name { get; set; }
    }
}