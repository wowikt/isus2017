﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Isus2017Mpa.Configuration.Dto;

namespace Isus2017Mpa.Configuration
{
    public interface IConfigurationAppService: IApplicationService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}